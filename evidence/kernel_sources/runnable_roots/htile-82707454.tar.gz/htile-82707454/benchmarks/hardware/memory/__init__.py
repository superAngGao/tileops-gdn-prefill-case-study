"""Memory subsystem microbenchmarks."""
